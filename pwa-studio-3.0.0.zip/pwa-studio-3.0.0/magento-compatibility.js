/**
 * This file describes PWA Studio to Magento version compatabilities.
 */

// PWA Studio version -> Magento version.
module.exports = {
    '>2.0.0': '>=2.3.1',
    '2.0.0': '2.3.0'
};
