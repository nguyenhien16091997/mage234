const mockCreate = jest.fn();

const dropin = {
    create: mockCreate
};

module.exports = dropin;
