const data = {
    items: [
        {
            item_id: 27,
            name: 'Crown Summit Backpack',
            image: {
                file: '/image.jpg'
            }
        },
        {
            item_id: 28,
            name: 'Crown Summit Backpack',
            image: {
                file: '/image.jpg'
            }
        }
    ]
};

export default data;
