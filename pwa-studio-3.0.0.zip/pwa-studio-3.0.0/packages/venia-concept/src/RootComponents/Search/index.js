/**
 * @RootComponent
 * description = 'Basic Search'
 * pageTypes = SEARCH
 */
export { default as Search } from './search';
export { default } from './container';
