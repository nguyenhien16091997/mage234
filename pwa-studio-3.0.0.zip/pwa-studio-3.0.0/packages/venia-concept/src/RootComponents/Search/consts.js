export const SEARCH_QUERY_PARAMETER = 'query';
