/**
 * @RootComponent
 * description = 'Basic Product Page'
 * pageTypes = PRODUCT
 */

export { default } from './Product';
