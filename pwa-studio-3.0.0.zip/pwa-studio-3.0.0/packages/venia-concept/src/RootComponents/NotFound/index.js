/**
 * @RootComponent
 * description = 'Page to display when offline'
 * pageTypes = NOTFOUND
 */
export { default } from './notFound';
