/**
 * @RootComponent
 * description = 'Basic CMS Page'
 * pageTypes = CMS_PAGE
 */

export { default } from './CMS';
