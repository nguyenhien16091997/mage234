/**
 * @RootComponent
 * description = 'Basic Category Page'
 * pageTypes = CATEGORY
 */
export { default } from './category';
