export { default } from './errorView';
