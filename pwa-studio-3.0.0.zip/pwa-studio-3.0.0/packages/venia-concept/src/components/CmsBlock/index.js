export { default } from './cmsBlock';
