export { default } from './indicator';
export { default as loadingIndicator } from './static';
