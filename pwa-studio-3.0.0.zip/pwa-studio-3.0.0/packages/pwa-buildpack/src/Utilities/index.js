module.exports = {
    addImgOptMiddleware: require('./addImgOptMiddleware'),
    configureHost: require('./configureHost')
};
