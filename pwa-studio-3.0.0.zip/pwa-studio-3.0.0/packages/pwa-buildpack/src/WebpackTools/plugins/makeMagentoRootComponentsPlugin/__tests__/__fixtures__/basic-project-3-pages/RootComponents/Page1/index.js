/**
 * @RootComponent
 * pageTypes = product_page
 */
