/**
 * @RootComponent
 * pageTypes = catalog_page
 */
