// should have a root component directive, but does not
