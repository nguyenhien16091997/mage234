/**
 * @RootComponent
 * pageTypes = product_page
 * description = "test test"
 */

/**
 * @RootComponent
 * pageTypes = catalog_page
 * description = "this is a duplicate"
 */
