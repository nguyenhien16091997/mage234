/**
 * @RootComponent
 * pageTypes = cms_page
 * description = 'CMS Page Root Component'
 */
