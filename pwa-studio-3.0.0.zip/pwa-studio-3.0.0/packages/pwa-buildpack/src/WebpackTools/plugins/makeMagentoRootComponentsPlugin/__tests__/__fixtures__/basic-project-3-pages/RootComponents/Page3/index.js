/**
 * @RootComponent
 * pageTypes = product_page_special
 * description = 'Special Product Pages'
 */
