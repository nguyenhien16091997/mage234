/**
 * @RootComponent
 * description = "This root component's dependencies should resolve"
 */

import dep from '../../dep';
