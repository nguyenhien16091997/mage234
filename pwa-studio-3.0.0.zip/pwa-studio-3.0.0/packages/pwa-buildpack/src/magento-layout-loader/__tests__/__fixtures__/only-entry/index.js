import React from 'react';

// Should warn about data-mid on Composite Component
const el = <Foo data-mid="bizz.bazz" />;
