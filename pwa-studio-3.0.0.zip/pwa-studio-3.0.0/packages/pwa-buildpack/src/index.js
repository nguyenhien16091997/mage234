const magentoLayoutLoader = require('./magento-layout-loader');
module.exports = {
    magentoLayoutLoader,
    WebpackTools: require('./WebpackTools'),
    Utilities: require('./Utilities')
};
