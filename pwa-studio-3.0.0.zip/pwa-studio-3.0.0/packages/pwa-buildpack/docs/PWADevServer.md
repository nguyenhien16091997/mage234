# PWADevServer

Documentation content has been moved to the [PWADevServer][] page in the PWA devdocs site.

[PWADevServer]: https://magento-research.github.io/pwa-studio/pwa-buildpack/reference/pwa-dev-server/
