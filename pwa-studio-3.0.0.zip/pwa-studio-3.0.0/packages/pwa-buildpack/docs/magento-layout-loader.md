# magento-layout-loader

Documentation content has been moved to the [magento-layout-loader][] page in the PWA devdocs site.

[magento-layout-loader]: https://magento-research.github.io/pwa-studio/pwa-buildpack/reference/layout-loader/
