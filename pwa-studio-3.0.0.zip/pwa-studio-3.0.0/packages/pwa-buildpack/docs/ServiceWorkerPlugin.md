# ServiceWorkerPlugin

Documentation content has been moved to the [ServiceWorkerPlugin][] page in the PWA devdocs site.

[ServiceWorkerPlugin]: https://magento-research.github.io/pwa-studio/pwa-buildpack/reference/serviceworker-plugin/
