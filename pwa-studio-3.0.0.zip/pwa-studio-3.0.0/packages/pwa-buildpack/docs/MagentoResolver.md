# MagentoResolver

Documentation content has been moved to the [MagentoResolver][] page on the PWA devdocs site.

[MagentoResolver]: https://magento-research.github.io/pwa-studio/pwa-buildpack/reference/magento-resolver/
