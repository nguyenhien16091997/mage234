# MagentoRootComponentsPlugin

Documentation content has been moved to the [MagentoRootComponentsPlugin] page in the PWA devdocs site.

[MagentoRootComponentsPlugin]: https://magento-research.github.io/pwa-studio/pwa-buildpack/reference/root-components-plugin/
