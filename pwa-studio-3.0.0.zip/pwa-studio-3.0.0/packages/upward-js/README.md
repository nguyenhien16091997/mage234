# upward-js

Documentation for this project has been moved to the [upward-js reference implementation][] in the PWA devdocs site.

[upward-js reference implementation]: https://magento-research.github.io/pwa-studio/technologies/upward/reference-implementation/
