const plugin = require('./lib/index.js');

module.exports = plugin;
