# REST API Clients

Documentation has been moved to the [REST API client][] topic in the PWA devdocs site.

[REST API client]: https://magento-research.github.io/pwa-studio/peregrine/reference/rest-api-client/
