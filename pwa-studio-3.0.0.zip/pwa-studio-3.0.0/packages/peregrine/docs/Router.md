# Peregrine Router

Documentation content has been moved to the [Router][] topic in the PWA devdocs site.

[Router]: https://magento-research.github.io/pwa-studio/peregrine/reference/router/

