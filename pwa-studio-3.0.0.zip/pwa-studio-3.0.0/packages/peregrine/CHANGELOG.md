# Change Log

All notable changes to this project will be documented in this file.
See [Conventional Commits](https://conventionalcommits.org) for commit guidelines.

<a name="0.5.0"></a>
# 0.5.0 (2018-08-13)


### Features

* multicasting REST API client ([#164](https://github.com/magento-research/pwa-studio/issues/164)) ([2852e14](https://github.com/magento-research/pwa-studio/commit/2852e14)), closes [#140](https://github.com/magento-research/pwa-studio/issues/140)
* Simulators for async testing ([#24](https://github.com/magento-research/pwa-studio/issues/24)) ([a380da9](https://github.com/magento-research/pwa-studio/commit/a380da9))
