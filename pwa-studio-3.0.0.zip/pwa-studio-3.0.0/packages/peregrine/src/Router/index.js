export { default as MagentoRouteHandler } from './MagentoRouteHandler';
export {
    default,
    Consumer as RouteConsumer,
    Provider as RouteProvider
} from './Router';
