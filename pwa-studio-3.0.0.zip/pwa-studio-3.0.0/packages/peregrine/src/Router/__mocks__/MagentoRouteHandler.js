import React, { Component } from 'react';

export default class MagentoRouteHandler extends Component {
    render() {
        return <i>hello</i>;
    }
}
