export { default } from './Price';
