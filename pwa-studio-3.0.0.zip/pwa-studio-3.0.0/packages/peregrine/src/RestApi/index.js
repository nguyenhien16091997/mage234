import * as Magento2 from './Magento2';

export { Magento2 };
