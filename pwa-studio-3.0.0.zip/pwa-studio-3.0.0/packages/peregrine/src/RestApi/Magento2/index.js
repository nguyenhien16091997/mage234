export { default, request } from './M2ApiRequest';
