export { default as BrowserPersistence } from './simplePersistence';
