const config = {
    parser: 'babel-eslint',
    extends: ['@magento']
};

module.exports = config;
